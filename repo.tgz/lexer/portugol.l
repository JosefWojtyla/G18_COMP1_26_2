%{
#include "../parser/portugol.tab.h"
/*#include "portugol.tab.h"*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

extern int qtd_erros;
%}

%option noyywrap
%option yylineno

DIGITO      [0-9]
LETRA       [a-zA-Zà-úÀ-Ú_]
IDENTIFICADOR          {LETRA}({LETRA}|{DIGITO})*
NUM_INT     {DIGITO}+
NUM_REAL    {DIGITO}+"."{DIGITO}+
ESPACO      [ \t\r\n]+  


%%

"//".*          {/*comentario de linha so ignora*/}
"/*"([^*]|\*+[^*/])*\*+"/" {/* ignora comentário de bloco */}

"{"                         { return ABRE_CHAVE; }
"}"                         { return FECHA_CHAVE; }
"["                         { return ABRE_COLCH; }
"]"                         { return FECHA_COLCH; }
"programa"                  { return PROGRAMA;}
"inicio"                    { return INICIO; }
"inclua"                    {return INCLUA;}
"const"                     {return CONST;}
"cadeia"                    {return T_CADEIA;}
"caracter"                  {return CARACTER;}
"inteiro"                   { return T_INTEIRO; }
"real"                      { return T_REAL; }
"logico"                    { return T_LOGICO; }

"escreva"                   { return ESCREVA; }
"leia"                      { return LEIA; }
"funcao"                    { return FUNCAO; }
"procedimento"              { return PROCEDIMENTO; }
"retorne"                  { return RETORNE; }

"verdadeiro"               { return VERDADEIRO; }
"falso"                    { return FALSO; }
"e"                        { return E; }
"ou"                       { return OU; }
"nao"                      { return NAO; }
"se"                       { return SE; }
"entao"                    { return ENTAO; }
"senao"                    { return SENAO; }
"enquanto"                 { return ENQUANTO; }
"faca"                     { return FACA; }
"para"                     { return PARA; }
"ate"                      { return ATE; }

"++"    { return MAIS_MAIS; }
"--"    { return MENOS_MENOS; }
"+="    { return MAIS_IGUAL; }
"-="    { return MENOS_IGUAL; }
"*="    { return VEZES_IGUAL; }
"/="    { return DIVIDE_IGUAL; }

"=="                       { return IGUAL; }
"="                        { return ATRIBUICAO; }
"!="                       { return DIFERENTE; }
"<="                       { return MENOR_IGUAL; }
">="                       { return MAIOR_IGUAL; }
"<"                        { return MENOR; }
">"                        { return MAIOR; }
"+"                        { return MAIS; }
"-"                        { return MENOS; }
"*"                        { return VEZES; }
"/"                        { return DIVIDE; }
"%"                        { return MODULO; }
"("                        { return ABRE_PAR; }
")"                        { return FECHA_PAR; }
","                        { return VIRGULA; }
";"                        { return PONTO_VIRGULA; }
":"                        { return DOIS_PONTOS; }

\"[^\"]*\"                 { yylval.str = strdup(yytext); return STRING; }
{NUM_REAL}                 { yylval.real = atof(yytext); return REAL; }
{NUM_INT}                  { yylval.inteiro = atoi(yytext); return INTEIRO; }
{IDENTIFICADOR}                       { yylval.str = strdup(yytext); return IDENTIFICADOR; }

{ESPACO}                   { /* ignora espaços */ }

.                          { fprintf(stderr, "Erro léxico: caractere inválido '%s' na linha %d\n", yytext, yylineno); qtd_erros++; }

%%






