/* A Bison parser, made by GNU Bison 3.8.2.  */

/* Bison implementation for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015, 2018-2021 Free Software Foundation,
   Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <https://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* C LALR(1) parser skeleton written by Richard Stallman, by
   simplifying the original so-called "semantic" parser.  */

/* DO NOT RELY ON FEATURES THAT ARE NOT DOCUMENTED in the manual,
   especially those whose name start with YY_ or yy_.  They are
   private implementation details that can be changed or removed.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output, and Bison version.  */
#define YYBISON 30802

/* Bison version string.  */
#define YYBISON_VERSION "3.8.2"

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 0

/* Push parsers.  */
#define YYPUSH 0

/* Pull parsers.  */
#define YYPULL 1




/* First part of user prologue.  */
#line 1 "parser/portugol.y"

/* Seção de Prologue ( Declara ções C/C++) */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "../src/simbolos.h"
#include "../src/ast.h"

AstNode *raiz_ast = NULL; 

TabelaSimbolos *tabela;

char *tipo_retorno_atual = NULL;

void yyerror(const char *s); /* função de erro */
extern int yylex(void);        /* função do Flex */
extern int yylineno;            /* linha atual (do Flex) */
extern FILE *yyin;

static AstNode *adicionar_ao_bloco(AstNode *bloco, AstNode *comando, int linha) {
    AstNode *atual;

    if (comando == NULL) return bloco;
    if (bloco == NULL) return criar_no_bloco(comando, NULL, linha);

    atual = bloco;
    while (atual->dados.bloco.proximo != NULL) {
        atual = atual->dados.bloco.proximo;
    }
    atual->dados.bloco.proximo = criar_no_bloco(comando, NULL, linha);
    return bloco;
}

static AstNode *concatenar_blocos(AstNode *primeiro, AstNode *segundo) {
    AstNode *atual;

    if (primeiro == NULL) return segundo;
    if (segundo == NULL) return primeiro;

    atual = primeiro;
    while (atual->dados.bloco.proximo != NULL) {
        atual = atual->dados.bloco.proximo;
    }
    atual->dados.bloco.proximo = segundo;
    return primeiro;
}


#line 121 "parser/portugol.tab.c"

# ifndef YY_CAST
#  ifdef __cplusplus
#   define YY_CAST(Type, Val) static_cast<Type> (Val)
#   define YY_REINTERPRET_CAST(Type, Val) reinterpret_cast<Type> (Val)
#  else
#   define YY_CAST(Type, Val) ((Type) (Val))
#   define YY_REINTERPRET_CAST(Type, Val) ((Type) (Val))
#  endif
# endif
# ifndef YY_NULLPTR
#  if defined __cplusplus
#   if 201103L <= __cplusplus
#    define YY_NULLPTR nullptr
#   else
#    define YY_NULLPTR 0
#   endif
#  else
#   define YY_NULLPTR ((void*)0)
#  endif
# endif

#include "portugol.tab.h"
/* Symbol kind.  */
enum yysymbol_kind_t
{
  YYSYMBOL_YYEMPTY = -2,
  YYSYMBOL_YYEOF = 0,                      /* "end of file"  */
  YYSYMBOL_YYerror = 1,                    /* error  */
  YYSYMBOL_YYUNDEF = 2,                    /* "invalid token"  */
  YYSYMBOL_PROGRAMA = 3,                   /* PROGRAMA  */
  YYSYMBOL_FUNCAO = 4,                     /* FUNCAO  */
  YYSYMBOL_INICIO = 5,                     /* INICIO  */
  YYSYMBOL_T_INTEIRO = 6,                  /* T_INTEIRO  */
  YYSYMBOL_T_REAL = 7,                     /* T_REAL  */
  YYSYMBOL_T_CADEIA = 8,                   /* T_CADEIA  */
  YYSYMBOL_T_LOGICO = 9,                   /* T_LOGICO  */
  YYSYMBOL_ESCREVA = 10,                   /* ESCREVA  */
  YYSYMBOL_LEIA = 11,                      /* LEIA  */
  YYSYMBOL_SE = 12,                        /* SE  */
  YYSYMBOL_ENTAO = 13,                     /* ENTAO  */
  YYSYMBOL_SENAO = 14,                     /* SENAO  */
  YYSYMBOL_FIMSE = 15,                     /* FIMSE  */
  YYSYMBOL_ENQUANTO = 16,                  /* ENQUANTO  */
  YYSYMBOL_FACA = 17,                      /* FACA  */
  YYSYMBOL_FIMENQUANTO = 18,               /* FIMENQUANTO  */
  YYSYMBOL_PARA = 19,                      /* PARA  */
  YYSYMBOL_ATE = 20,                       /* ATE  */
  YYSYMBOL_FIMPARA = 21,                   /* FIMPARA  */
  YYSYMBOL_RETORNE = 22,                   /* RETORNE  */
  YYSYMBOL_VERDADEIRO = 23,                /* VERDADEIRO  */
  YYSYMBOL_FALSO = 24,                     /* FALSO  */
  YYSYMBOL_E = 25,                         /* E  */
  YYSYMBOL_OU = 26,                        /* OU  */
  YYSYMBOL_NAO = 27,                       /* NAO  */
  YYSYMBOL_ABRE_PAR = 28,                  /* ABRE_PAR  */
  YYSYMBOL_FECHA_PAR = 29,                 /* FECHA_PAR  */
  YYSYMBOL_ABRE_CHAVE = 30,                /* ABRE_CHAVE  */
  YYSYMBOL_FECHA_CHAVE = 31,               /* FECHA_CHAVE  */
  YYSYMBOL_ABRE_COLCH = 32,                /* ABRE_COLCH  */
  YYSYMBOL_FECHA_COLCH = 33,               /* FECHA_COLCH  */
  YYSYMBOL_VIRGULA = 34,                   /* VIRGULA  */
  YYSYMBOL_PONTO_VIRGULA = 35,             /* PONTO_VIRGULA  */
  YYSYMBOL_DOIS_PONTOS = 36,               /* DOIS_PONTOS  */
  YYSYMBOL_ATRIBUICAO = 37,                /* ATRIBUICAO  */
  YYSYMBOL_IGUAL = 38,                     /* IGUAL  */
  YYSYMBOL_DIFERENTE = 39,                 /* DIFERENTE  */
  YYSYMBOL_MENOR = 40,                     /* MENOR  */
  YYSYMBOL_MAIOR = 41,                     /* MAIOR  */
  YYSYMBOL_MENOR_IGUAL = 42,               /* MENOR_IGUAL  */
  YYSYMBOL_MAIOR_IGUAL = 43,               /* MAIOR_IGUAL  */
  YYSYMBOL_MAIS = 44,                      /* MAIS  */
  YYSYMBOL_MENOS = 45,                     /* MENOS  */
  YYSYMBOL_VEZES = 46,                     /* VEZES  */
  YYSYMBOL_DIVIDE = 47,                    /* DIVIDE  */
  YYSYMBOL_MODULO = 48,                    /* MODULO  */
  YYSYMBOL_MAIS_MAIS = 49,                 /* MAIS_MAIS  */
  YYSYMBOL_MENOS_MENOS = 50,               /* MENOS_MENOS  */
  YYSYMBOL_MAIS_IGUAL = 51,                /* MAIS_IGUAL  */
  YYSYMBOL_MENOS_IGUAL = 52,               /* MENOS_IGUAL  */
  YYSYMBOL_VEZES_IGUAL = 53,               /* VEZES_IGUAL  */
  YYSYMBOL_DIVIDE_IGUAL = 54,              /* DIVIDE_IGUAL  */
  YYSYMBOL_INCLUA = 55,                    /* INCLUA  */
  YYSYMBOL_CONST = 56,                     /* CONST  */
  YYSYMBOL_CARACTER = 57,                  /* CARACTER  */
  YYSYMBOL_PROCEDIMENTO = 58,              /* PROCEDIMENTO  */
  YYSYMBOL_INTEIRO = 59,                   /* INTEIRO  */
  YYSYMBOL_REAL = 60,                      /* REAL  */
  YYSYMBOL_STRING = 61,                    /* STRING  */
  YYSYMBOL_IDENTIFICADOR = 62,             /* IDENTIFICADOR  */
  YYSYMBOL_YYACCEPT = 63,                  /* $accept  */
  YYSYMBOL_declaracoes_globais = 64,       /* declaracoes_globais  */
  YYSYMBOL_programa = 65,                  /* programa  */
  YYSYMBOL_lista_funcoes = 66,             /* lista_funcoes  */
  YYSYMBOL_funcao_inicio = 67,             /* funcao_inicio  */
  YYSYMBOL_68_1 = 68,                      /* $@1  */
  YYSYMBOL_bloco = 69,                     /* bloco  */
  YYSYMBOL_comando = 70,                   /* comando  */
  YYSYMBOL_declaracao = 71,                /* declaracao  */
  YYSYMBOL_declaracao_funcao = 72,         /* declaracao_funcao  */
  YYSYMBOL_73_2 = 73,                      /* $@2  */
  YYSYMBOL_74_3 = 74,                      /* $@3  */
  YYSYMBOL_tipo = 75,                      /* tipo  */
  YYSYMBOL_enquanto_comando = 76,          /* enquanto_comando  */
  YYSYMBOL_77_4 = 77,                      /* $@4  */
  YYSYMBOL_se_comando = 78,                /* se_comando  */
  YYSYMBOL_79_5 = 79,                      /* $@5  */
  YYSYMBOL_80_6 = 80,                      /* $@6  */
  YYSYMBOL_senao_opcional = 81,            /* senao_opcional  */
  YYSYMBOL_82_7 = 82,                      /* $@7  */
  YYSYMBOL_lista_parametros = 83,          /* lista_parametros  */
  YYSYMBOL_expressao = 84,                 /* expressao  */
  YYSYMBOL_chamada_funcao = 85,            /* chamada_funcao  */
  YYSYMBOL_lista_argumentos = 86,          /* lista_argumentos  */
  YYSYMBOL_acesso_vetor = 87,              /* acesso_vetor  */
  YYSYMBOL_inicializacao_para = 88,        /* inicializacao_para  */
  YYSYMBOL_incremento_para = 89,           /* incremento_para  */
  YYSYMBOL_para_comando = 90,              /* para_comando  */
  YYSYMBOL_91_8 = 91                       /* $@8  */
};
typedef enum yysymbol_kind_t yysymbol_kind_t;




#ifdef short
# undef short
#endif

/* On compilers that do not define __PTRDIFF_MAX__ etc., make sure
   <limits.h> and (if available) <stdint.h> are included
   so that the code can choose integer types of a good width.  */

#ifndef __PTRDIFF_MAX__
# include <limits.h> /* INFRINGES ON USER NAME SPACE */
# if defined __STDC_VERSION__ && 199901 <= __STDC_VERSION__
#  include <stdint.h> /* INFRINGES ON USER NAME SPACE */
#  define YY_STDINT_H
# endif
#endif

/* Narrow types that promote to a signed type and that can represent a
   signed or unsigned integer of at least N bits.  In tables they can
   save space and decrease cache pressure.  Promoting to a signed type
   helps avoid bugs in integer arithmetic.  */

#ifdef __INT_LEAST8_MAX__
typedef __INT_LEAST8_TYPE__ yytype_int8;
#elif defined YY_STDINT_H
typedef int_least8_t yytype_int8;
#else
typedef signed char yytype_int8;
#endif

#ifdef __INT_LEAST16_MAX__
typedef __INT_LEAST16_TYPE__ yytype_int16;
#elif defined YY_STDINT_H
typedef int_least16_t yytype_int16;
#else
typedef short yytype_int16;
#endif

/* Work around bug in HP-UX 11.23, which defines these macros
   incorrectly for preprocessor constants.  This workaround can likely
   be removed in 2023, as HPE has promised support for HP-UX 11.23
   (aka HP-UX 11i v2) only through the end of 2022; see Table 2 of
   <https://h20195.www2.hpe.com/V2/getpdf.aspx/4AA4-7673ENW.pdf>.  */
#ifdef __hpux
# undef UINT_LEAST8_MAX
# undef UINT_LEAST16_MAX
# define UINT_LEAST8_MAX 255
# define UINT_LEAST16_MAX 65535
#endif

#if defined __UINT_LEAST8_MAX__ && __UINT_LEAST8_MAX__ <= __INT_MAX__
typedef __UINT_LEAST8_TYPE__ yytype_uint8;
#elif (!defined __UINT_LEAST8_MAX__ && defined YY_STDINT_H \
       && UINT_LEAST8_MAX <= INT_MAX)
typedef uint_least8_t yytype_uint8;
#elif !defined __UINT_LEAST8_MAX__ && UCHAR_MAX <= INT_MAX
typedef unsigned char yytype_uint8;
#else
typedef short yytype_uint8;
#endif

#if defined __UINT_LEAST16_MAX__ && __UINT_LEAST16_MAX__ <= __INT_MAX__
typedef __UINT_LEAST16_TYPE__ yytype_uint16;
#elif (!defined __UINT_LEAST16_MAX__ && defined YY_STDINT_H \
       && UINT_LEAST16_MAX <= INT_MAX)
typedef uint_least16_t yytype_uint16;
#elif !defined __UINT_LEAST16_MAX__ && USHRT_MAX <= INT_MAX
typedef unsigned short yytype_uint16;
#else
typedef int yytype_uint16;
#endif

#ifndef YYPTRDIFF_T
# if defined __PTRDIFF_TYPE__ && defined __PTRDIFF_MAX__
#  define YYPTRDIFF_T __PTRDIFF_TYPE__
#  define YYPTRDIFF_MAXIMUM __PTRDIFF_MAX__
# elif defined PTRDIFF_MAX
#  ifndef ptrdiff_t
#   include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  endif
#  define YYPTRDIFF_T ptrdiff_t
#  define YYPTRDIFF_MAXIMUM PTRDIFF_MAX
# else
#  define YYPTRDIFF_T long
#  define YYPTRDIFF_MAXIMUM LONG_MAX
# endif
#endif

#ifndef YYSIZE_T
# ifdef __SIZE_TYPE__
#  define YYSIZE_T __SIZE_TYPE__
# elif defined size_t
#  define YYSIZE_T size_t
# elif defined __STDC_VERSION__ && 199901 <= __STDC_VERSION__
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# else
#  define YYSIZE_T unsigned
# endif
#endif

#define YYSIZE_MAXIMUM                                  \
  YY_CAST (YYPTRDIFF_T,                                 \
           (YYPTRDIFF_MAXIMUM < YY_CAST (YYSIZE_T, -1)  \
            ? YYPTRDIFF_MAXIMUM                         \
            : YY_CAST (YYSIZE_T, -1)))

#define YYSIZEOF(X) YY_CAST (YYPTRDIFF_T, sizeof (X))


/* Stored state numbers (used for stacks). */
typedef yytype_uint8 yy_state_t;

/* State numbers in computations.  */
typedef int yy_state_fast_t;

#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(Msgid) dgettext ("bison-runtime", Msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(Msgid) Msgid
# endif
#endif


#ifndef YY_ATTRIBUTE_PURE
# if defined __GNUC__ && 2 < __GNUC__ + (96 <= __GNUC_MINOR__)
#  define YY_ATTRIBUTE_PURE __attribute__ ((__pure__))
# else
#  define YY_ATTRIBUTE_PURE
# endif
#endif

#ifndef YY_ATTRIBUTE_UNUSED
# if defined __GNUC__ && 2 < __GNUC__ + (7 <= __GNUC_MINOR__)
#  define YY_ATTRIBUTE_UNUSED __attribute__ ((__unused__))
# else
#  define YY_ATTRIBUTE_UNUSED
# endif
#endif

/* Suppress unused-variable warnings by "using" E.  */
#if ! defined lint || defined __GNUC__
# define YY_USE(E) ((void) (E))
#else
# define YY_USE(E) /* empty */
#endif

/* Suppress an incorrect diagnostic about yylval being uninitialized.  */
#if defined __GNUC__ && ! defined __ICC && 406 <= __GNUC__ * 100 + __GNUC_MINOR__
# if __GNUC__ * 100 + __GNUC_MINOR__ < 407
#  define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN                           \
    _Pragma ("GCC diagnostic push")                                     \
    _Pragma ("GCC diagnostic ignored \"-Wuninitialized\"")
# else
#  define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN                           \
    _Pragma ("GCC diagnostic push")                                     \
    _Pragma ("GCC diagnostic ignored \"-Wuninitialized\"")              \
    _Pragma ("GCC diagnostic ignored \"-Wmaybe-uninitialized\"")
# endif
# define YY_IGNORE_MAYBE_UNINITIALIZED_END      \
    _Pragma ("GCC diagnostic pop")
#else
# define YY_INITIAL_VALUE(Value) Value
#endif
#ifndef YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_END
#endif
#ifndef YY_INITIAL_VALUE
# define YY_INITIAL_VALUE(Value) /* Nothing. */
#endif

#if defined __cplusplus && defined __GNUC__ && ! defined __ICC && 6 <= __GNUC__
# define YY_IGNORE_USELESS_CAST_BEGIN                          \
    _Pragma ("GCC diagnostic push")                            \
    _Pragma ("GCC diagnostic ignored \"-Wuseless-cast\"")
# define YY_IGNORE_USELESS_CAST_END            \
    _Pragma ("GCC diagnostic pop")
#endif
#ifndef YY_IGNORE_USELESS_CAST_BEGIN
# define YY_IGNORE_USELESS_CAST_BEGIN
# define YY_IGNORE_USELESS_CAST_END
#endif


#define YY_ASSERT(E) ((void) (0 && (E)))

#if !defined yyoverflow

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# ifdef YYSTACK_USE_ALLOCA
#  if YYSTACK_USE_ALLOCA
#   ifdef __GNUC__
#    define YYSTACK_ALLOC __builtin_alloca
#   elif defined __BUILTIN_VA_ARG_INCR
#    include <alloca.h> /* INFRINGES ON USER NAME SPACE */
#   elif defined _AIX
#    define YYSTACK_ALLOC __alloca
#   elif defined _MSC_VER
#    include <malloc.h> /* INFRINGES ON USER NAME SPACE */
#    define alloca _alloca
#   else
#    define YYSTACK_ALLOC alloca
#    if ! defined _ALLOCA_H && ! defined EXIT_SUCCESS
#     include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
      /* Use EXIT_SUCCESS as a witness for stdlib.h.  */
#     ifndef EXIT_SUCCESS
#      define EXIT_SUCCESS 0
#     endif
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's 'empty if-body' warning.  */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (0)
#  ifndef YYSTACK_ALLOC_MAXIMUM
    /* The OS might guarantee only one guard page at the bottom of the stack,
       and a page size can be as small as 4096 bytes.  So we cannot safely
       invoke alloca (N) if N exceeds 4096.  Use a slightly smaller number
       to allow for a few compiler-allocated temporary stack slots.  */
#   define YYSTACK_ALLOC_MAXIMUM 4032 /* reasonable circa 2006 */
#  endif
# else
#  define YYSTACK_ALLOC YYMALLOC
#  define YYSTACK_FREE YYFREE
#  ifndef YYSTACK_ALLOC_MAXIMUM
#   define YYSTACK_ALLOC_MAXIMUM YYSIZE_MAXIMUM
#  endif
#  if (defined __cplusplus && ! defined EXIT_SUCCESS \
       && ! ((defined YYMALLOC || defined malloc) \
             && (defined YYFREE || defined free)))
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   ifndef EXIT_SUCCESS
#    define EXIT_SUCCESS 0
#   endif
#  endif
#  ifndef YYMALLOC
#   define YYMALLOC malloc
#   if ! defined malloc && ! defined EXIT_SUCCESS
void *malloc (YYSIZE_T); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifndef YYFREE
#   define YYFREE free
#   if ! defined free && ! defined EXIT_SUCCESS
void free (void *); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
# endif
#endif /* !defined yyoverflow */

#if (! defined yyoverflow \
     && (! defined __cplusplus \
         || (defined YYSTYPE_IS_TRIVIAL && YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  yy_state_t yyss_alloc;
  YYSTYPE yyvs_alloc;
};

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (YYSIZEOF (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (YYSIZEOF (yy_state_t) + YYSIZEOF (YYSTYPE)) \
      + YYSTACK_GAP_MAXIMUM)

# define YYCOPY_NEEDED 1

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack_alloc, Stack)                           \
    do                                                                  \
      {                                                                 \
        YYPTRDIFF_T yynewbytes;                                         \
        YYCOPY (&yyptr->Stack_alloc, Stack, yysize);                    \
        Stack = &yyptr->Stack_alloc;                                    \
        yynewbytes = yystacksize * YYSIZEOF (*Stack) + YYSTACK_GAP_MAXIMUM; \
        yyptr += yynewbytes / YYSIZEOF (*yyptr);                        \
      }                                                                 \
    while (0)

#endif

#if defined YYCOPY_NEEDED && YYCOPY_NEEDED
/* Copy COUNT objects from SRC to DST.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if defined __GNUC__ && 1 < __GNUC__
#   define YYCOPY(Dst, Src, Count) \
      __builtin_memcpy (Dst, Src, YY_CAST (YYSIZE_T, (Count)) * sizeof (*(Src)))
#  else
#   define YYCOPY(Dst, Src, Count)              \
      do                                        \
        {                                       \
          YYPTRDIFF_T yyi;                      \
          for (yyi = 0; yyi < (Count); yyi++)   \
            (Dst)[yyi] = (Src)[yyi];            \
        }                                       \
      while (0)
#  endif
# endif
#endif /* !YYCOPY_NEEDED */

/* YYFINAL -- State number of the termination state.  */
#define YYFINAL  4
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   460

/* YYNTOKENS -- Number of terminals.  */
#define YYNTOKENS  63
/* YYNNTS -- Number of nonterminals.  */
#define YYNNTS  29
/* YYNRULES -- Number of rules.  */
#define YYNRULES  79
/* YYNSTATES -- Number of states.  */
#define YYNSTATES  177

/* YYMAXUTOK -- Last valid token kind.  */
#define YYMAXUTOK   317


/* YYTRANSLATE(TOKEN-NUM) -- Symbol number corresponding to TOKEN-NUM
   as returned by yylex, with out-of-bounds checking.  */
#define YYTRANSLATE(YYX)                                \
  (0 <= (YYX) && (YYX) <= YYMAXUTOK                     \
   ? YY_CAST (yysymbol_kind_t, yytranslate[YYX])        \
   : YYSYMBOL_YYUNDEF)

/* YYTRANSLATE[TOKEN-NUM] -- Symbol number corresponding to TOKEN-NUM
   as returned by yylex.  */
static const yytype_int8 yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    57,    58,    59,    60,    61,    62
};

#if YYDEBUG
/* YYRLINE[YYN] -- Source line where rule number YYN was defined.  */
static const yytype_int16 yyrline[] =
{
       0,   117,   117,   118,   122,   137,   138,   144,   142,   156,
     157,   166,   167,   180,   185,   196,   198,   200,   209,   214,
     219,   225,   235,   252,   263,   261,   280,   278,   300,   301,
     302,   303,   308,   307,   321,   326,   320,   336,   339,   338,
     350,   363,   381,   383,   385,   387,   389,   391,   393,   395,
     397,   399,   401,   403,   405,   407,   409,   411,   413,   415,
     417,   419,   421,   423,   425,   430,   435,   443,   444,   449,
     458,   471,   486,   491,   496,   501,   506,   511,   520,   519
};
#endif

/** Accessing symbol of state STATE.  */
#define YY_ACCESSING_SYMBOL(State) YY_CAST (yysymbol_kind_t, yystos[State])

#if YYDEBUG || 0
/* The user-facing name of the symbol whose (internal) number is
   YYSYMBOL.  No bounds checking.  */
static const char *yysymbol_name (yysymbol_kind_t yysymbol) YY_ATTRIBUTE_UNUSED;

/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals.  */
static const char *const yytname[] =
{
  "\"end of file\"", "error", "\"invalid token\"", "PROGRAMA", "FUNCAO",
  "INICIO", "T_INTEIRO", "T_REAL", "T_CADEIA", "T_LOGICO", "ESCREVA",
  "LEIA", "SE", "ENTAO", "SENAO", "FIMSE", "ENQUANTO", "FACA",
  "FIMENQUANTO", "PARA", "ATE", "FIMPARA", "RETORNE", "VERDADEIRO",
  "FALSO", "E", "OU", "NAO", "ABRE_PAR", "FECHA_PAR", "ABRE_CHAVE",
  "FECHA_CHAVE", "ABRE_COLCH", "FECHA_COLCH", "VIRGULA", "PONTO_VIRGULA",
  "DOIS_PONTOS", "ATRIBUICAO", "IGUAL", "DIFERENTE", "MENOR", "MAIOR",
  "MENOR_IGUAL", "MAIOR_IGUAL", "MAIS", "MENOS", "VEZES", "DIVIDE",
  "MODULO", "MAIS_MAIS", "MENOS_MENOS", "MAIS_IGUAL", "MENOS_IGUAL",
  "VEZES_IGUAL", "DIVIDE_IGUAL", "INCLUA", "CONST", "CARACTER",
  "PROCEDIMENTO", "INTEIRO", "REAL", "STRING", "IDENTIFICADOR", "$accept",
  "declaracoes_globais", "programa", "lista_funcoes", "funcao_inicio",
  "$@1", "bloco", "comando", "declaracao", "declaracao_funcao", "$@2",
  "$@3", "tipo", "enquanto_comando", "$@4", "se_comando", "$@5", "$@6",
  "senao_opcional", "$@7", "lista_parametros", "expressao",
  "chamada_funcao", "lista_argumentos", "acesso_vetor",
  "inicializacao_para", "incremento_para", "para_comando", "$@8", YY_NULLPTR
};

static const char *
yysymbol_name (yysymbol_kind_t yysymbol)
{
  return yytname[yysymbol];
}
#endif

#define YYPACT_NINF (-79)

#define yypact_value_is_default(Yyn) \
  ((Yyn) == YYPACT_NINF)

#define YYTABLE_NINF (-1)

#define yytable_value_is_error(Yyn) \
  0

/* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
   STATE-NUM.  */
static const yytype_int16 yypact[] =
{
       6,     8,    37,   -79,   -79,   118,   -79,   -79,   -79,   -79,
      39,   -79,   -17,    98,   -79,   -79,   -26,    13,    -8,     3,
       1,   228,    32,    42,   118,   -79,    34,   -79,   -79,   228,
     228,   -79,   -79,   -79,     7,   388,   -79,   -79,    38,    57,
     -79,   -79,   257,   219,   228,   228,   228,   228,   228,   228,
     228,   228,   228,   228,   228,   228,   228,   228,   -79,    64,
      36,   -21,   -79,   -79,   388,     2,   281,   400,   412,    75,
      75,    75,    75,    75,    75,   138,   138,   -79,   -79,   -79,
     -79,   -79,   -79,    66,   118,   -79,   228,   -79,    40,   -79,
     -79,    46,   388,    73,    82,    85,    86,    88,   228,   -79,
      55,   -79,   -79,   -79,   -79,   -79,    80,   -79,   127,   -79,
     -79,   228,    78,   228,   228,   -79,   388,   228,   228,   -79,
     144,   305,    99,   329,   353,    -4,   388,   388,   -79,   -79,
     -79,   129,   128,   107,    95,   112,   131,   132,   228,   111,
     228,   -79,   -79,   388,   228,   377,   -79,   -79,   388,    97,
     161,   188,    27,   135,   -79,   -79,   -79,   -79,   228,   228,
     228,   228,   146,   151,   388,   388,   388,   388,   -79,   148,
     -79,   205,   -79,   -79,   -79,   222,   -79
};

/* YYDEFACT[STATE-NUM] -- Default reduction number in state STATE-NUM.
   Performed when YYTABLE does not specify something else to do.  Zero
   means the default is an error.  */
static const yytype_int8 yydefact[] =
{
       0,     0,     0,     2,     1,     5,    28,    29,    30,    31,
       0,     3,     0,     0,     5,     6,    21,     0,     0,     0,
       0,     0,     0,     0,     0,     4,     0,    46,    47,     0,
       0,    42,    43,    44,    45,    22,    63,    64,     0,     0,
      23,    62,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     7,     0,
       0,     0,    48,    65,    67,     0,     0,    60,    61,    54,
      55,    56,    57,    58,    59,    49,    50,    51,    52,    53,
       9,    24,    40,     0,     0,    66,     0,    69,     0,     9,
      26,     0,    68,     0,     0,     0,     0,     0,     0,     8,
       0,    10,    11,    16,    15,    18,     0,    20,     0,     9,
      41,     0,     0,     0,     0,    78,    17,     0,     0,    25,
       0,     0,     0,     0,     0,     0,    12,    19,    27,    13,
      14,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,    34,    32,    71,     0,     0,     9,     9,    70,     0,
       0,     0,     0,     0,    35,    33,    72,    73,     0,     0,
       0,     0,     0,    37,    74,    75,    76,    77,     9,     0,
      36,     0,    38,    79,     9,     0,    39
};

/* YYPGOTO[NTERM-NUM].  */
static const yytype_int16 yypgoto[] =
{
     -79,   -79,   -79,   160,   -79,   -79,   -56,   -79,   174,   -79,
     -79,   -79,    16,   -79,   -79,   -79,   -79,   -79,   -79,   -79,
     -79,   -29,   -78,   -79,   -76,   -79,   -79,   -79,   -79
};

/* YYDEFGOTO[NTERM-NUM].  */
static const yytype_uint8 yydefgoto[] =
{
       0,     5,     2,    10,    14,    80,    88,   101,   102,    15,
      89,   109,    12,   103,   147,   104,   146,   163,   170,   174,
      61,    35,    36,    65,    37,   135,   153,   107,   125
};

/* YYTABLE[YYPACT[STATE-NUM]] -- What to do in state STATE-NUM.  If
   positive, shift that token.  If negative, reduce the rule whose
   number is the opposite.  If YYTABLE_NINF, syntax error.  */
static const yytype_uint8 yytable[] =
{
      41,    42,     6,     7,     8,     9,    20,    24,    83,     1,
     105,    21,   106,    84,    64,    66,    67,    68,    69,    70,
      71,    72,    73,    74,    75,    76,    77,    78,    79,    18,
     105,    85,   106,   108,    25,    43,    86,     4,     3,    44,
      18,    22,   105,    13,   106,    16,     6,     7,     8,     9,
      93,    94,    95,   120,    23,    60,    96,    92,   133,    97,
      26,    38,    98,     6,     7,     8,     9,    40,    58,   116,
      39,    99,   105,   105,   106,   106,   156,   157,   158,   159,
     160,   161,   121,    43,   123,   124,    59,    44,   126,   127,
     150,   151,   117,   105,    81,   106,    90,   105,    82,   106,
      91,   111,   100,    17,     6,     7,     8,     9,   110,   143,
     112,   145,   171,   113,   114,   148,   115,   118,   175,    53,
      54,    55,    56,    57,     6,     7,     8,     9,   130,   164,
     165,   166,   167,     6,     7,     8,     9,    93,    94,    95,
     122,   134,   136,    96,   138,   137,    97,   140,   144,    98,
       6,     7,     8,     9,    93,    94,    95,   139,   119,   152,
      96,   141,   142,    97,   162,   169,    98,     6,     7,     8,
       9,    93,    94,    95,    19,   128,   168,    96,   172,    11,
      97,     0,     0,    98,    55,    56,    57,     0,     0,   100,
       0,     0,   154,     0,     6,     7,     8,     9,    93,    94,
      95,     0,     0,     0,    96,     0,   100,    97,     0,     0,
      98,     6,     7,     8,     9,    93,    94,    95,     0,   155,
       0,    96,     0,   100,    97,     0,     0,    98,     6,     7,
       8,     9,    93,    94,    95,     0,   173,     0,    96,     0,
       0,    97,    27,    28,    98,     0,    29,    30,    63,     0,
     100,    27,    28,   176,     0,    29,    30,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   100,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,    31,    32,
      33,    34,    45,    46,   100,     0,    62,    31,    32,    33,
      34,     0,     0,     0,     0,    47,    48,    49,    50,    51,
      52,    53,    54,    55,    56,    57,    45,    46,     0,     0,
       0,     0,     0,     0,    87,     0,     0,     0,     0,    47,
      48,    49,    50,    51,    52,    53,    54,    55,    56,    57,
      45,    46,     0,     0,   129,     0,     0,     0,     0,     0,
       0,     0,     0,    47,    48,    49,    50,    51,    52,    53,
      54,    55,    56,    57,    45,    46,     0,     0,   131,     0,
       0,     0,     0,     0,     0,     0,     0,    47,    48,    49,
      50,    51,    52,    53,    54,    55,    56,    57,    45,    46,
       0,     0,   132,     0,     0,     0,     0,     0,     0,     0,
       0,    47,    48,    49,    50,    51,    52,    53,    54,    55,
      56,    57,    45,    46,     0,     0,     0,     0,     0,     0,
       0,     0,   149,    45,    46,    47,    48,    49,    50,    51,
      52,    53,    54,    55,    56,    57,    47,    48,    49,    50,
      51,    52,    53,    54,    55,    56,    57,    45,    47,    48,
      49,    50,    51,    52,    53,    54,    55,    56,    57,     0,
      47,    48,    49,    50,    51,    52,    53,    54,    55,    56,
      57
};

static const yytype_int16 yycheck[] =
{
      29,    30,     6,     7,     8,     9,    32,     4,    29,     3,
      88,    37,    88,    34,    43,    44,    45,    46,    47,    48,
      49,    50,    51,    52,    53,    54,    55,    56,    57,    13,
     108,    29,   108,    89,    31,    28,    34,     0,    30,    32,
      24,    28,   120,     4,   120,    62,     6,     7,     8,     9,
      10,    11,    12,   109,    62,    39,    16,    86,    62,    19,
      59,    29,    22,     6,     7,     8,     9,    33,    30,    98,
      28,    31,   150,   151,   150,   151,    49,    50,    51,    52,
      53,    54,   111,    28,   113,   114,    29,    32,   117,   118,
     146,   147,    37,   171,    30,   171,    30,   175,    62,   175,
      84,    28,    62,     5,     6,     7,     8,     9,    62,   138,
      28,   140,   168,    28,    28,   144,    28,    37,   174,    44,
      45,    46,    47,    48,     6,     7,     8,     9,    29,   158,
     159,   160,   161,     6,     7,     8,     9,    10,    11,    12,
      62,   125,    13,    16,    37,    17,    19,    35,    37,    22,
       6,     7,     8,     9,    10,    11,    12,    62,    31,    62,
      16,    30,    30,    19,    29,    14,    22,     6,     7,     8,
       9,    10,    11,    12,    14,    31,    30,    16,    30,     5,
      19,    -1,    -1,    22,    46,    47,    48,    -1,    -1,    62,
      -1,    -1,    31,    -1,     6,     7,     8,     9,    10,    11,
      12,    -1,    -1,    -1,    16,    -1,    62,    19,    -1,    -1,
      22,     6,     7,     8,     9,    10,    11,    12,    -1,    31,
      -1,    16,    -1,    62,    19,    -1,    -1,    22,     6,     7,
       8,     9,    10,    11,    12,    -1,    31,    -1,    16,    -1,
      -1,    19,    23,    24,    22,    -1,    27,    28,    29,    -1,
      62,    23,    24,    31,    -1,    27,    28,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    62,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    59,    60,
      61,    62,    25,    26,    62,    -1,    29,    59,    60,    61,
      62,    -1,    -1,    -1,    -1,    38,    39,    40,    41,    42,
      43,    44,    45,    46,    47,    48,    25,    26,    -1,    -1,
      -1,    -1,    -1,    -1,    33,    -1,    -1,    -1,    -1,    38,
      39,    40,    41,    42,    43,    44,    45,    46,    47,    48,
      25,    26,    -1,    -1,    29,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    25,    26,    -1,    -1,    29,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    38,    39,    40,
      41,    42,    43,    44,    45,    46,    47,    48,    25,    26,
      -1,    -1,    29,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    38,    39,    40,    41,    42,    43,    44,    45,    46,
      47,    48,    25,    26,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    35,    25,    26,    38,    39,    40,    41,    42,
      43,    44,    45,    46,    47,    48,    38,    39,    40,    41,
      42,    43,    44,    45,    46,    47,    48,    25,    38,    39,
      40,    41,    42,    43,    44,    45,    46,    47,    48,    -1,
      38,    39,    40,    41,    42,    43,    44,    45,    46,    47,
      48
};

/* YYSTOS[STATE-NUM] -- The symbol kind of the accessing symbol of
   state STATE-NUM.  */
static const yytype_int8 yystos[] =
{
       0,     3,    65,    30,     0,    64,     6,     7,     8,     9,
      66,    71,    75,     4,    67,    72,    62,     5,    75,    66,
      32,    37,    28,    62,     4,    31,    59,    23,    24,    27,
      28,    59,    60,    61,    62,    84,    85,    87,    29,    28,
      33,    84,    84,    28,    32,    25,    26,    38,    39,    40,
      41,    42,    43,    44,    45,    46,    47,    48,    30,    29,
      75,    83,    29,    29,    84,    86,    84,    84,    84,    84,
      84,    84,    84,    84,    84,    84,    84,    84,    84,    84,
      68,    30,    62,    29,    34,    29,    34,    33,    69,    73,
      30,    75,    84,    10,    11,    12,    16,    19,    22,    31,
      62,    70,    71,    76,    78,    85,    87,    90,    69,    74,
      62,    28,    28,    28,    28,    28,    84,    37,    37,    31,
      69,    84,    62,    84,    84,    91,    84,    84,    31,    29,
      29,    29,    29,    62,    75,    88,    13,    17,    37,    62,
      35,    30,    30,    84,    37,    84,    79,    77,    84,    35,
      69,    69,    62,    89,    31,    31,    49,    50,    51,    52,
      53,    54,    29,    80,    84,    84,    84,    84,    30,    14,
      81,    69,    30,    31,    82,    69,    31
};

/* YYR1[RULE-NUM] -- Symbol kind of the left-hand side of rule RULE-NUM.  */
static const yytype_int8 yyr1[] =
{
       0,    63,    64,    64,    65,    66,    66,    68,    67,    69,
      69,    70,    70,    70,    70,    70,    70,    70,    70,    70,
      70,    71,    71,    71,    73,    72,    74,    72,    75,    75,
      75,    75,    77,    76,    79,    80,    78,    81,    82,    81,
      83,    83,    84,    84,    84,    84,    84,    84,    84,    84,
      84,    84,    84,    84,    84,    84,    84,    84,    84,    84,
      84,    84,    84,    84,    84,    85,    85,    86,    86,    87,
      88,    88,    89,    89,    89,    89,    89,    89,    91,    90
};

/* YYR2[RULE-NUM] -- Number of symbols on the right-hand side of rule RULE-NUM.  */
static const yytype_int8 yyr2[] =
{
       0,     2,     0,     2,     7,     0,     2,     0,     8,     0,
       2,     1,     3,     4,     4,     1,     1,     2,     1,     3,
       1,     2,     4,     5,     0,     9,     0,    10,     1,     1,
       1,     1,     0,     9,     0,     0,    11,     0,     0,     5,
       2,     4,     1,     1,     1,     1,     1,     1,     3,     3,
       3,     3,     3,     3,     3,     3,     3,     3,     3,     3,
       3,     3,     2,     1,     1,     3,     4,     1,     3,     4,
       4,     3,     2,     2,     3,     3,     3,     3,     0,    12
};


enum { YYENOMEM = -2 };

#define yyerrok         (yyerrstatus = 0)
#define yyclearin       (yychar = YYEMPTY)

#define YYACCEPT        goto yyacceptlab
#define YYABORT         goto yyabortlab
#define YYERROR         goto yyerrorlab
#define YYNOMEM         goto yyexhaustedlab


#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)                                    \
  do                                                              \
    if (yychar == YYEMPTY)                                        \
      {                                                           \
        yychar = (Token);                                         \
        yylval = (Value);                                         \
        YYPOPSTACK (yylen);                                       \
        yystate = *yyssp;                                         \
        goto yybackup;                                            \
      }                                                           \
    else                                                          \
      {                                                           \
        yyerror (YY_("syntax error: cannot back up")); \
        YYERROR;                                                  \
      }                                                           \
  while (0)

/* Backward compatibility with an undocumented macro.
   Use YYerror or YYUNDEF. */
#define YYERRCODE YYUNDEF


/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)                        \
do {                                            \
  if (yydebug)                                  \
    YYFPRINTF Args;                             \
} while (0)




# define YY_SYMBOL_PRINT(Title, Kind, Value, Location)                    \
do {                                                                      \
  if (yydebug)                                                            \
    {                                                                     \
      YYFPRINTF (stderr, "%s ", Title);                                   \
      yy_symbol_print (stderr,                                            \
                  Kind, Value); \
      YYFPRINTF (stderr, "\n");                                           \
    }                                                                     \
} while (0)


/*-----------------------------------.
| Print this symbol's value on YYO.  |
`-----------------------------------*/

static void
yy_symbol_value_print (FILE *yyo,
                       yysymbol_kind_t yykind, YYSTYPE const * const yyvaluep)
{
  FILE *yyoutput = yyo;
  YY_USE (yyoutput);
  if (!yyvaluep)
    return;
  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  YY_USE (yykind);
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}


/*---------------------------.
| Print this symbol on YYO.  |
`---------------------------*/

static void
yy_symbol_print (FILE *yyo,
                 yysymbol_kind_t yykind, YYSTYPE const * const yyvaluep)
{
  YYFPRINTF (yyo, "%s %s (",
             yykind < YYNTOKENS ? "token" : "nterm", yysymbol_name (yykind));

  yy_symbol_value_print (yyo, yykind, yyvaluep);
  YYFPRINTF (yyo, ")");
}

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (included).                                                   |
`------------------------------------------------------------------*/

static void
yy_stack_print (yy_state_t *yybottom, yy_state_t *yytop)
{
  YYFPRINTF (stderr, "Stack now");
  for (; yybottom <= yytop; yybottom++)
    {
      int yybot = *yybottom;
      YYFPRINTF (stderr, " %d", yybot);
    }
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)                            \
do {                                                            \
  if (yydebug)                                                  \
    yy_stack_print ((Bottom), (Top));                           \
} while (0)


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

static void
yy_reduce_print (yy_state_t *yyssp, YYSTYPE *yyvsp,
                 int yyrule)
{
  int yylno = yyrline[yyrule];
  int yynrhs = yyr2[yyrule];
  int yyi;
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %d):\n",
             yyrule - 1, yylno);
  /* The symbols being reduced.  */
  for (yyi = 0; yyi < yynrhs; yyi++)
    {
      YYFPRINTF (stderr, "   $%d = ", yyi + 1);
      yy_symbol_print (stderr,
                       YY_ACCESSING_SYMBOL (+yyssp[yyi + 1 - yynrhs]),
                       &yyvsp[(yyi + 1) - (yynrhs)]);
      YYFPRINTF (stderr, "\n");
    }
}

# define YY_REDUCE_PRINT(Rule)          \
do {                                    \
  if (yydebug)                          \
    yy_reduce_print (yyssp, yyvsp, Rule); \
} while (0)

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args) ((void) 0)
# define YY_SYMBOL_PRINT(Title, Kind, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   YYSTACK_ALLOC_MAXIMUM < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif






/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

static void
yydestruct (const char *yymsg,
            yysymbol_kind_t yykind, YYSTYPE *yyvaluep)
{
  YY_USE (yyvaluep);
  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yykind, yyvaluep, yylocationp);

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  YY_USE (yykind);
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}


/* Lookahead token kind.  */
int yychar;

/* The semantic value of the lookahead symbol.  */
YYSTYPE yylval;
/* Number of syntax errors so far.  */
int yynerrs;




/*----------.
| yyparse.  |
`----------*/

int
yyparse (void)
{
    yy_state_fast_t yystate = 0;
    /* Number of tokens to shift before error messages enabled.  */
    int yyerrstatus = 0;

    /* Refer to the stacks through separate pointers, to allow yyoverflow
       to reallocate them elsewhere.  */

    /* Their size.  */
    YYPTRDIFF_T yystacksize = YYINITDEPTH;

    /* The state stack: array, bottom, top.  */
    yy_state_t yyssa[YYINITDEPTH];
    yy_state_t *yyss = yyssa;
    yy_state_t *yyssp = yyss;

    /* The semantic value stack: array, bottom, top.  */
    YYSTYPE yyvsa[YYINITDEPTH];
    YYSTYPE *yyvs = yyvsa;
    YYSTYPE *yyvsp = yyvs;

  int yyn;
  /* The return value of yyparse.  */
  int yyresult;
  /* Lookahead symbol kind.  */
  yysymbol_kind_t yytoken = YYSYMBOL_YYEMPTY;
  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;



#define YYPOPSTACK(N)   (yyvsp -= (N), yyssp -= (N))

  /* The number of symbols on the RHS of the reduced rule.
     Keep to zero when no symbol should be popped.  */
  int yylen = 0;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yychar = YYEMPTY; /* Cause a token to be read.  */

  goto yysetstate;


/*------------------------------------------------------------.
| yynewstate -- push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed.  So pushing a state here evens the stacks.  */
  yyssp++;


/*--------------------------------------------------------------------.
| yysetstate -- set current state (the top of the stack) to yystate.  |
`--------------------------------------------------------------------*/
yysetstate:
  YYDPRINTF ((stderr, "Entering state %d\n", yystate));
  YY_ASSERT (0 <= yystate && yystate < YYNSTATES);
  YY_IGNORE_USELESS_CAST_BEGIN
  *yyssp = YY_CAST (yy_state_t, yystate);
  YY_IGNORE_USELESS_CAST_END
  YY_STACK_PRINT (yyss, yyssp);

  if (yyss + yystacksize - 1 <= yyssp)
#if !defined yyoverflow && !defined YYSTACK_RELOCATE
    YYNOMEM;
#else
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYPTRDIFF_T yysize = yyssp - yyss + 1;

# if defined yyoverflow
      {
        /* Give user a chance to reallocate the stack.  Use copies of
           these so that the &'s don't force the real ones into
           memory.  */
        yy_state_t *yyss1 = yyss;
        YYSTYPE *yyvs1 = yyvs;

        /* Each stack pointer address is followed by the size of the
           data in use in that stack, in bytes.  This used to be a
           conditional around just the two extra args, but that might
           be undefined if yyoverflow is a macro.  */
        yyoverflow (YY_("memory exhausted"),
                    &yyss1, yysize * YYSIZEOF (*yyssp),
                    &yyvs1, yysize * YYSIZEOF (*yyvsp),
                    &yystacksize);
        yyss = yyss1;
        yyvs = yyvs1;
      }
# else /* defined YYSTACK_RELOCATE */
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
        YYNOMEM;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
        yystacksize = YYMAXDEPTH;

      {
        yy_state_t *yyss1 = yyss;
        union yyalloc *yyptr =
          YY_CAST (union yyalloc *,
                   YYSTACK_ALLOC (YY_CAST (YYSIZE_T, YYSTACK_BYTES (yystacksize))));
        if (! yyptr)
          YYNOMEM;
        YYSTACK_RELOCATE (yyss_alloc, yyss);
        YYSTACK_RELOCATE (yyvs_alloc, yyvs);
#  undef YYSTACK_RELOCATE
        if (yyss1 != yyssa)
          YYSTACK_FREE (yyss1);
      }
# endif

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;

      YY_IGNORE_USELESS_CAST_BEGIN
      YYDPRINTF ((stderr, "Stack size increased to %ld\n",
                  YY_CAST (long, yystacksize)));
      YY_IGNORE_USELESS_CAST_END

      if (yyss + yystacksize - 1 <= yyssp)
        YYABORT;
    }
#endif /* !defined yyoverflow && !defined YYSTACK_RELOCATE */


  if (yystate == YYFINAL)
    YYACCEPT;

  goto yybackup;


/*-----------.
| yybackup.  |
`-----------*/
yybackup:
  /* Do appropriate processing given the current state.  Read a
     lookahead token if we need one and don't already have one.  */

  /* First try to decide what to do without reference to lookahead token.  */
  yyn = yypact[yystate];
  if (yypact_value_is_default (yyn))
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* YYCHAR is either empty, or end-of-input, or a valid lookahead.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token\n"));
      yychar = yylex ();
    }

  if (yychar <= YYEOF)
    {
      yychar = YYEOF;
      yytoken = YYSYMBOL_YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else if (yychar == YYerror)
    {
      /* The scanner already issued an error message, process directly
         to error recovery.  But do not keep the error token as
         lookahead, it is too special and may lead us to an endless
         loop in error recovery. */
      yychar = YYUNDEF;
      yytoken = YYSYMBOL_YYerror;
      goto yyerrlab1;
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yytable_value_is_error (yyn))
        goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  /* Shift the lookahead token.  */
  YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);
  yystate = yyn;
  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END

  /* Discard the shifted token.  */
  yychar = YYEMPTY;
  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     '$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];


  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
  case 2: /* declaracoes_globais: %empty  */
#line 117 "parser/portugol.y"
             { (yyval.no) = NULL; }
#line 1374 "parser/portugol.tab.c"
    break;

  case 3: /* declaracoes_globais: declaracoes_globais declaracao  */
#line 118 "parser/portugol.y"
                                     { (yyval.no) = adicionar_ao_bloco((yyvsp[-1].no), (yyvsp[0].no), yylineno); }
#line 1380 "parser/portugol.tab.c"
    break;

  case 4: /* programa: PROGRAMA ABRE_CHAVE declaracoes_globais lista_funcoes funcao_inicio lista_funcoes FECHA_CHAVE  */
#line 128 "parser/portugol.y"
      {
          AstNode *nos = concatenar_blocos((yyvsp[-4].no), (yyvsp[-3].no));
          nos = adicionar_ao_bloco(nos, (yyvsp[-2].no), yylineno);
          raiz_ast = concatenar_blocos(nos, (yyvsp[-1].no));
          (yyval.no) = raiz_ast;
      }
#line 1391 "parser/portugol.tab.c"
    break;

  case 5: /* lista_funcoes: %empty  */
#line 137 "parser/portugol.y"
             { (yyval.no) = NULL; }
#line 1397 "parser/portugol.tab.c"
    break;

  case 6: /* lista_funcoes: lista_funcoes declaracao_funcao  */
#line 138 "parser/portugol.y"
                                      { (yyval.no) = adicionar_ao_bloco((yyvsp[-1].no), (yyvsp[0].no), yylineno); }
#line 1403 "parser/portugol.tab.c"
    break;

  case 7: /* $@1: %empty  */
#line 144 "parser/portugol.y"
      {
          abrirEscopo(tabela);
      }
#line 1411 "parser/portugol.tab.c"
    break;

  case 8: /* funcao_inicio: FUNCAO INICIO ABRE_PAR FECHA_PAR ABRE_CHAVE $@1 bloco FECHA_CHAVE  */
#line 148 "parser/portugol.y"
      {
          fecharEscopo(tabela);
          (yyval.no) = (yyvsp[-1].no);
      }
#line 1420 "parser/portugol.tab.c"
    break;

  case 9: /* bloco: %empty  */
#line 156 "parser/portugol.y"
             { (yyval.no) = NULL; }
#line 1426 "parser/portugol.tab.c"
    break;

  case 10: /* bloco: bloco comando  */
#line 158 "parser/portugol.y"
        {
            (yyval.no) = adicionar_ao_bloco((yyvsp[-1].no), (yyvsp[0].no), yylineno);
        }
#line 1434 "parser/portugol.tab.c"
    break;

  case 11: /* comando: declaracao  */
#line 166 "parser/portugol.y"
                 { (yyval.no) = (yyvsp[0].no); }
#line 1440 "parser/portugol.tab.c"
    break;

  case 12: /* comando: IDENTIFICADOR ATRIBUICAO expressao  */
#line 168 "parser/portugol.y"
        {
            Simbolo *s = buscarSimbolo(tabela, (yyvsp[-2].str));
            if (s == NULL) {
                yyerror("Variável usada sem declaração");
            } else {
                verificar_atribuicao(s->tipo, (yyvsp[0].no), yylineno, tabela);
                s->inicializado = 1;
            }

            (yyval.no) = criar_no_atribuicao((yyvsp[-2].str), (yyvsp[0].no), yylineno);
            free((yyvsp[-2].str));
        }
#line 1457 "parser/portugol.tab.c"
    break;

  case 13: /* comando: ESCREVA ABRE_PAR expressao FECHA_PAR  */
#line 181 "parser/portugol.y"
        { 
            inferir_tipo((yyvsp[-1].no), tabela);
            (yyval.no) = criar_no_escreva((yyvsp[-1].no), yylineno); 
        }
#line 1466 "parser/portugol.tab.c"
    break;

  case 14: /* comando: LEIA ABRE_PAR IDENTIFICADOR FECHA_PAR  */
#line 186 "parser/portugol.y"
        { 
            Simbolo *s = buscarSimbolo(tabela, (yyvsp[-1].str));
            if(s == NULL){
                yyerror("Variavel usasda sem declaracao.");
            } else {
                s->inicializado = 1;
            }
            (yyval.no) = criar_no_leia((yyvsp[-1].str), yylineno); 
            free((yyvsp[-1].str));
        }
#line 1481 "parser/portugol.tab.c"
    break;

  case 15: /* comando: se_comando  */
#line 197 "parser/portugol.y"
        { (yyval.no) = (yyvsp[0].no); }
#line 1487 "parser/portugol.tab.c"
    break;

  case 16: /* comando: enquanto_comando  */
#line 199 "parser/portugol.y"
        { (yyval.no) = (yyvsp[0].no); }
#line 1493 "parser/portugol.tab.c"
    break;

  case 17: /* comando: RETORNE expressao  */
#line 201 "parser/portugol.y"
        { 
            if (tipo_retorno_atual != NULL) {
                verificar_atribuicao(tipo_retorno_atual, (yyvsp[0].no), yylineno, tabela);
            } else {
                inferir_tipo((yyvsp[0].no), tabela);
            }
            (yyval.no) = criar_no_retorne((yyvsp[0].no), yylineno); 
        }
#line 1506 "parser/portugol.tab.c"
    break;

  case 18: /* comando: chamada_funcao  */
#line 210 "parser/portugol.y"
        {
            inferir_tipo((yyvsp[0].no), tabela); 
            (yyval.no) = (yyvsp[0].no); 
        }
#line 1515 "parser/portugol.tab.c"
    break;

  case 19: /* comando: acesso_vetor ATRIBUICAO expressao  */
#line 215 "parser/portugol.y"
    {
        liberar_ast((yyvsp[0].no));
        (yyval.no) = NULL;
    }
#line 1524 "parser/portugol.tab.c"
    break;

  case 20: /* comando: para_comando  */
#line 220 "parser/portugol.y"
        { (yyval.no) = (yyvsp[0].no); }
#line 1530 "parser/portugol.tab.c"
    break;

  case 21: /* declaracao: tipo IDENTIFICADOR  */
#line 226 "parser/portugol.y"
        {   
            if(!inserirSimbolo(tabela, (yyvsp[0].str), (yyvsp[-1].str), yylineno, tabela->escopo_atual)){
                yyerror("Variável já declarada neste escopo");
            }
            free((yyvsp[-1].str));
            free((yyvsp[0].str));
            (yyval.no) = NULL;
        }
#line 1543 "parser/portugol.tab.c"
    break;

  case 22: /* declaracao: tipo IDENTIFICADOR ATRIBUICAO expressao  */
#line 236 "parser/portugol.y"
        {
            
            if(!inserirSimbolo(tabela, (yyvsp[-2].str), (yyvsp[-3].str), yylineno, tabela->escopo_atual)){
                yyerror("Variável já declarada neste escopo");
            } else {
                Simbolo *s = buscarSimbolo(tabela, (yyvsp[-2].str));

                if(s != NULL){
                    s->inicializado = 1;
                }
            }
            verificar_atribuicao((yyvsp[-3].str), (yyvsp[0].no), yylineno, tabela);
            (yyval.no) = criar_no_atribuicao((yyvsp[-2].str), (yyvsp[0].no), yylineno);
            free((yyvsp[-3].str));
            free((yyvsp[-2].str));
        }
#line 1564 "parser/portugol.tab.c"
    break;

  case 23: /* declaracao: tipo IDENTIFICADOR ABRE_COLCH INTEIRO FECHA_COLCH  */
#line 253 "parser/portugol.y"
        {
            free((yyvsp[-4].str));
            free((yyvsp[-3].str));
            (yyval.no) = NULL; /* Não há nó de declaração de vetor no design atual. */
        }
#line 1574 "parser/portugol.tab.c"
    break;

  case 24: /* $@2: %empty  */
#line 263 "parser/portugol.y"
                 {
          inserirSimbolo(tabela, (yyvsp[-3].str), (yyvsp[-4].str), yylineno, 0);
          tipo_retorno_atual = (yyvsp[-4].str);
          abrirEscopo(tabela);
      }
#line 1584 "parser/portugol.tab.c"
    break;

  case 25: /* declaracao_funcao: FUNCAO tipo IDENTIFICADOR ABRE_PAR FECHA_PAR ABRE_CHAVE $@2 bloco FECHA_CHAVE  */
#line 268 "parser/portugol.y"
        {
            fecharEscopo(tabela);
            tipo_retorno_atual = NULL;
            if (!verificar_retorno_garantido((yyvsp[-1].no))) {
                yyerror("Funcao nao possui retorno garantido em todos os caminhos");
            }
            (yyval.no) = criar_no_funcao((yyvsp[-6].str), (yyvsp[-7].str), NULL, (yyvsp[-1].no), yylineno);
            free((yyvsp[-7].str));
            free((yyvsp[-6].str));
        }
#line 1599 "parser/portugol.tab.c"
    break;

  case 26: /* $@3: %empty  */
#line 280 "parser/portugol.y"
                 {
          inserirSimbolo(tabela, (yyvsp[-4].str), (yyvsp[-5].str), yylineno, 0);
          Simbolo *f = buscarSimbolo(tabela, (yyvsp[-4].str));
          if (f) f->parametros = (yyvsp[-2].no);
          tipo_retorno_atual = (yyvsp[-5].str);
          abrirEscopo(tabela);
      }
#line 1611 "parser/portugol.tab.c"
    break;

  case 27: /* declaracao_funcao: FUNCAO tipo IDENTIFICADOR ABRE_PAR lista_parametros FECHA_PAR ABRE_CHAVE $@3 bloco FECHA_CHAVE  */
#line 287 "parser/portugol.y"
        {
            fecharEscopo(tabela);
            tipo_retorno_atual = NULL;
            if (!verificar_retorno_garantido((yyvsp[-1].no))) {
                yyerror("Funcao nao possui retorno garantido em todos os caminhos");
            }
            (yyval.no) = criar_no_funcao((yyvsp[-7].str), (yyvsp[-8].str), (yyvsp[-5].no), (yyvsp[-1].no), yylineno);
            free((yyvsp[-8].str));
            free((yyvsp[-7].str));
        }
#line 1626 "parser/portugol.tab.c"
    break;

  case 28: /* tipo: T_INTEIRO  */
#line 300 "parser/portugol.y"
                    { (yyval.str) = strdup("inteiro"); }
#line 1632 "parser/portugol.tab.c"
    break;

  case 29: /* tipo: T_REAL  */
#line 301 "parser/portugol.y"
                    { (yyval.str) = strdup("real"); }
#line 1638 "parser/portugol.tab.c"
    break;

  case 30: /* tipo: T_CADEIA  */
#line 302 "parser/portugol.y"
                    { (yyval.str) = strdup("cadeia"); }
#line 1644 "parser/portugol.tab.c"
    break;

  case 31: /* tipo: T_LOGICO  */
#line 303 "parser/portugol.y"
                    { (yyval.str) = strdup("logico"); }
#line 1650 "parser/portugol.tab.c"
    break;

  case 32: /* $@4: %empty  */
#line 308 "parser/portugol.y"
        {
            verificar_condicao((yyvsp[-3].no), yylineno, tabela);
            abrirEscopo(tabela);
        }
#line 1659 "parser/portugol.tab.c"
    break;

  case 33: /* enquanto_comando: ENQUANTO ABRE_PAR expressao FECHA_PAR FACA ABRE_CHAVE $@4 bloco FECHA_CHAVE  */
#line 313 "parser/portugol.y"
        {
            fecharEscopo(tabela);
            (yyval.no) = criar_no_enquanto((yyvsp[-6].no), (yyvsp[-1].no), yylineno);
        }
#line 1668 "parser/portugol.tab.c"
    break;

  case 34: /* $@5: %empty  */
#line 321 "parser/portugol.y"
        {
            verificar_condicao((yyvsp[-3].no), yylineno, tabela);
            abrirEscopo(tabela);
        }
#line 1677 "parser/portugol.tab.c"
    break;

  case 35: /* $@6: %empty  */
#line 326 "parser/portugol.y"
        {
            fecharEscopo(tabela);
        }
#line 1685 "parser/portugol.tab.c"
    break;

  case 36: /* se_comando: SE ABRE_PAR expressao FECHA_PAR ENTAO ABRE_CHAVE $@5 bloco FECHA_CHAVE $@6 senao_opcional  */
#line 330 "parser/portugol.y"
        {
            (yyval.no) = criar_no_se((yyvsp[-8].no), (yyvsp[-3].no), (yyvsp[0].no), yylineno);
        }
#line 1693 "parser/portugol.tab.c"
    break;

  case 37: /* senao_opcional: %empty  */
#line 337 "parser/portugol.y"
        { (yyval.no) = NULL; }
#line 1699 "parser/portugol.tab.c"
    break;

  case 38: /* $@7: %empty  */
#line 339 "parser/portugol.y"
        {
            abrirEscopo(tabela);
        }
#line 1707 "parser/portugol.tab.c"
    break;

  case 39: /* senao_opcional: SENAO ABRE_CHAVE $@7 bloco FECHA_CHAVE  */
#line 343 "parser/portugol.y"
        {
            fecharEscopo(tabela);
            (yyval.no) = (yyvsp[-1].no);
        }
#line 1716 "parser/portugol.tab.c"
    break;

  case 40: /* lista_parametros: tipo IDENTIFICADOR  */
#line 351 "parser/portugol.y"
        {
            AstNode *parame = criar_no_parametro((yyvsp[0].str), (yyvsp[-1].str), yylineno);
            if(!inserirSimbolo(tabela, (yyvsp[0].str), (yyvsp[-1].str), yylineno, tabela->escopo_atual + 1)){
                yyerror("Parametro ja declarado neste escopo");
            } else {
                Simbolo *s = buscarSimbolo(tabela, (yyvsp[0].str));
                if(s) s->inicializado = 1;
            }
            (yyval.no) = adicionar_ao_bloco(NULL, parame, yylineno);
            free((yyvsp[-1].str));
            free((yyvsp[0].str));
        }
#line 1733 "parser/portugol.tab.c"
    break;

  case 41: /* lista_parametros: lista_parametros VIRGULA tipo IDENTIFICADOR  */
#line 364 "parser/portugol.y"
        {
            AstNode *parame = criar_no_parametro((yyvsp[0].str), (yyvsp[-1].str), yylineno);
            if(!inserirSimbolo(tabela, (yyvsp[0].str), (yyvsp[-1].str), yylineno, tabela->escopo_atual + 1)){
                yyerror("Parametro ja declarado neste escopo");
            } else {
                Simbolo *s = buscarSimbolo(tabela, (yyvsp[0].str));
                if(s) s->inicializado = 1;
            }
            (yyval.no) = adicionar_ao_bloco((yyvsp[-3].no), parame, yylineno);
            free((yyvsp[-1].str));
            free((yyvsp[0].str));
        }
#line 1750 "parser/portugol.tab.c"
    break;

  case 42: /* expressao: INTEIRO  */
#line 382 "parser/portugol.y"
        { (yyval.no) = criar_no_inteiro((yyvsp[0].inteiro), yylineno); }
#line 1756 "parser/portugol.tab.c"
    break;

  case 43: /* expressao: REAL  */
#line 384 "parser/portugol.y"
        { (yyval.no) = criar_no_real((yyvsp[0].real), yylineno); }
#line 1762 "parser/portugol.tab.c"
    break;

  case 44: /* expressao: STRING  */
#line 386 "parser/portugol.y"
        { (yyval.no) = criar_no_cadeia((yyvsp[0].str), yylineno); free((yyvsp[0].str)); }
#line 1768 "parser/portugol.tab.c"
    break;

  case 45: /* expressao: IDENTIFICADOR  */
#line 388 "parser/portugol.y"
        { (yyval.no) = criar_no_variavel((yyvsp[0].str), yylineno); free((yyvsp[0].str)); }
#line 1774 "parser/portugol.tab.c"
    break;

  case 46: /* expressao: VERDADEIRO  */
#line 390 "parser/portugol.y"
        { (yyval.no) = criar_no_logico(1, yylineno); }
#line 1780 "parser/portugol.tab.c"
    break;

  case 47: /* expressao: FALSO  */
#line 392 "parser/portugol.y"
        { (yyval.no) = criar_no_logico(0, yylineno); }
#line 1786 "parser/portugol.tab.c"
    break;

  case 48: /* expressao: ABRE_PAR expressao FECHA_PAR  */
#line 394 "parser/portugol.y"
        { (yyval.no) = (yyvsp[-1].no); }
#line 1792 "parser/portugol.tab.c"
    break;

  case 49: /* expressao: expressao MAIS expressao  */
#line 396 "parser/portugol.y"
        { (yyval.no) = criar_no_op_binaria("+", (yyvsp[-2].no), (yyvsp[0].no), yylineno); }
#line 1798 "parser/portugol.tab.c"
    break;

  case 50: /* expressao: expressao MENOS expressao  */
#line 398 "parser/portugol.y"
        { (yyval.no) = criar_no_op_binaria("-", (yyvsp[-2].no), (yyvsp[0].no), yylineno); }
#line 1804 "parser/portugol.tab.c"
    break;

  case 51: /* expressao: expressao VEZES expressao  */
#line 400 "parser/portugol.y"
        { (yyval.no) = criar_no_op_binaria("*", (yyvsp[-2].no), (yyvsp[0].no), yylineno); }
#line 1810 "parser/portugol.tab.c"
    break;

  case 52: /* expressao: expressao DIVIDE expressao  */
#line 402 "parser/portugol.y"
        { (yyval.no) = criar_no_op_binaria("/", (yyvsp[-2].no), (yyvsp[0].no), yylineno); }
#line 1816 "parser/portugol.tab.c"
    break;

  case 53: /* expressao: expressao MODULO expressao  */
#line 404 "parser/portugol.y"
        { (yyval.no) = criar_no_op_binaria("%", (yyvsp[-2].no), (yyvsp[0].no), yylineno); }
#line 1822 "parser/portugol.tab.c"
    break;

  case 54: /* expressao: expressao IGUAL expressao  */
#line 406 "parser/portugol.y"
        { (yyval.no) = criar_no_op_binaria("==", (yyvsp[-2].no), (yyvsp[0].no), yylineno); }
#line 1828 "parser/portugol.tab.c"
    break;

  case 55: /* expressao: expressao DIFERENTE expressao  */
#line 408 "parser/portugol.y"
        { (yyval.no) = criar_no_op_binaria("!=", (yyvsp[-2].no), (yyvsp[0].no), yylineno); }
#line 1834 "parser/portugol.tab.c"
    break;

  case 56: /* expressao: expressao MENOR expressao  */
#line 410 "parser/portugol.y"
        { (yyval.no) = criar_no_op_binaria("<", (yyvsp[-2].no), (yyvsp[0].no), yylineno); }
#line 1840 "parser/portugol.tab.c"
    break;

  case 57: /* expressao: expressao MAIOR expressao  */
#line 412 "parser/portugol.y"
        { (yyval.no) = criar_no_op_binaria(">", (yyvsp[-2].no), (yyvsp[0].no), yylineno); }
#line 1846 "parser/portugol.tab.c"
    break;

  case 58: /* expressao: expressao MENOR_IGUAL expressao  */
#line 414 "parser/portugol.y"
        { (yyval.no) = criar_no_op_binaria("<=", (yyvsp[-2].no), (yyvsp[0].no), yylineno); }
#line 1852 "parser/portugol.tab.c"
    break;

  case 59: /* expressao: expressao MAIOR_IGUAL expressao  */
#line 416 "parser/portugol.y"
        { (yyval.no) = criar_no_op_binaria(">=", (yyvsp[-2].no), (yyvsp[0].no), yylineno); }
#line 1858 "parser/portugol.tab.c"
    break;

  case 60: /* expressao: expressao E expressao  */
#line 418 "parser/portugol.y"
        { (yyval.no) = criar_no_op_binaria("e", (yyvsp[-2].no), (yyvsp[0].no), yylineno); }
#line 1864 "parser/portugol.tab.c"
    break;

  case 61: /* expressao: expressao OU expressao  */
#line 420 "parser/portugol.y"
        { (yyval.no) = criar_no_op_binaria("ou", (yyvsp[-2].no), (yyvsp[0].no), yylineno); }
#line 1870 "parser/portugol.tab.c"
    break;

  case 62: /* expressao: NAO expressao  */
#line 422 "parser/portugol.y"
        { (yyval.no) = criar_no_op_binaria("nao", NULL, (yyvsp[0].no), yylineno); }
#line 1876 "parser/portugol.tab.c"
    break;

  case 63: /* expressao: chamada_funcao  */
#line 424 "parser/portugol.y"
        { (yyval.no) = (yyvsp[0].no); }
#line 1882 "parser/portugol.tab.c"
    break;

  case 64: /* expressao: acesso_vetor  */
#line 426 "parser/portugol.y"
        { (yyval.no) = NULL; /* A AST ainda não representa acesso a vetor. */ }
#line 1888 "parser/portugol.tab.c"
    break;

  case 65: /* chamada_funcao: IDENTIFICADOR ABRE_PAR FECHA_PAR  */
#line 431 "parser/portugol.y"
        {
            (yyval.no) = criar_no_chamada((yyvsp[-2].str), NULL, yylineno);
            free((yyvsp[-2].str));
        }
#line 1897 "parser/portugol.tab.c"
    break;

  case 66: /* chamada_funcao: IDENTIFICADOR ABRE_PAR lista_argumentos FECHA_PAR  */
#line 436 "parser/portugol.y"
        {
            (yyval.no) = criar_no_chamada((yyvsp[-3].str), (yyvsp[-1].no), yylineno);
            free((yyvsp[-3].str));
        }
#line 1906 "parser/portugol.tab.c"
    break;

  case 67: /* lista_argumentos: expressao  */
#line 443 "parser/portugol.y"
                { (yyval.no) = adicionar_ao_bloco(NULL, (yyvsp[0].no), yylineno); }
#line 1912 "parser/portugol.tab.c"
    break;

  case 68: /* lista_argumentos: lista_argumentos VIRGULA expressao  */
#line 445 "parser/portugol.y"
        { (yyval.no) = adicionar_ao_bloco((yyvsp[-2].no), (yyvsp[0].no), yylineno); }
#line 1918 "parser/portugol.tab.c"
    break;

  case 69: /* acesso_vetor: IDENTIFICADOR ABRE_COLCH expressao FECHA_COLCH  */
#line 450 "parser/portugol.y"
        {
            free((yyvsp[-3].str));
            liberar_ast((yyvsp[-1].no));
            (yyval.no) = NULL; /* A AST ainda não possui nó de acesso a vetor. */
        }
#line 1928 "parser/portugol.tab.c"
    break;

  case 70: /* inicializacao_para: tipo IDENTIFICADOR ATRIBUICAO expressao  */
#line 459 "parser/portugol.y"
        {
            if(!inserirSimbolo(tabela, (yyvsp[-2].str), (yyvsp[-3].str), yylineno, tabela->escopo_atual)){
                yyerror("Variável já declarada neste escopo");
            } else {
                Simbolo *s = buscarSimbolo(tabela, (yyvsp[-2].str));
                if(s) s->inicializado = 1;
            }
            verificar_atribuicao((yyvsp[-3].str), (yyvsp[0].no), yylineno, tabela);
            (yyval.no) = criar_no_atribuicao((yyvsp[-2].str), (yyvsp[0].no), yylineno);
            free((yyvsp[-3].str));
            free((yyvsp[-2].str));
        }
#line 1945 "parser/portugol.tab.c"
    break;

  case 71: /* inicializacao_para: IDENTIFICADOR ATRIBUICAO expressao  */
#line 472 "parser/portugol.y"
        {
            Simbolo *s = buscarSimbolo(tabela, (yyvsp[-2].str));
            if(s == NULL){
                yyerror("Variável usada sem declaração");
            } else {
                verificar_atribuicao(s->tipo, (yyvsp[0].no), yylineno, tabela);
                s->inicializado = 1;
            }
            (yyval.no) = criar_no_atribuicao((yyvsp[-2].str), (yyvsp[0].no), yylineno);
            free((yyvsp[-2].str));
        }
#line 1961 "parser/portugol.tab.c"
    break;

  case 72: /* incremento_para: IDENTIFICADOR MAIS_MAIS  */
#line 487 "parser/portugol.y"
        {
            (yyval.no) = criar_no_atribuicao((yyvsp[-1].str), criar_no_op_binaria("+", criar_no_variavel((yyvsp[-1].str), yylineno), criar_no_inteiro(1, yylineno), yylineno), yylineno);
            free((yyvsp[-1].str));
        }
#line 1970 "parser/portugol.tab.c"
    break;

  case 73: /* incremento_para: IDENTIFICADOR MENOS_MENOS  */
#line 492 "parser/portugol.y"
        {
            (yyval.no) = criar_no_atribuicao((yyvsp[-1].str), criar_no_op_binaria("-", criar_no_variavel((yyvsp[-1].str), yylineno), criar_no_inteiro(1, yylineno), yylineno), yylineno);
            free((yyvsp[-1].str));
        }
#line 1979 "parser/portugol.tab.c"
    break;

  case 74: /* incremento_para: IDENTIFICADOR MAIS_IGUAL expressao  */
#line 497 "parser/portugol.y"
        {
            (yyval.no) = criar_no_atribuicao((yyvsp[-2].str), criar_no_op_binaria("+", criar_no_variavel((yyvsp[-2].str), yylineno), (yyvsp[0].no), yylineno), yylineno);
            free((yyvsp[-2].str));
        }
#line 1988 "parser/portugol.tab.c"
    break;

  case 75: /* incremento_para: IDENTIFICADOR MENOS_IGUAL expressao  */
#line 502 "parser/portugol.y"
        {
            (yyval.no) = criar_no_atribuicao((yyvsp[-2].str), criar_no_op_binaria("-", criar_no_variavel((yyvsp[-2].str), yylineno), (yyvsp[0].no), yylineno), yylineno);
            free((yyvsp[-2].str));
        }
#line 1997 "parser/portugol.tab.c"
    break;

  case 76: /* incremento_para: IDENTIFICADOR VEZES_IGUAL expressao  */
#line 507 "parser/portugol.y"
        {
            (yyval.no) = criar_no_atribuicao((yyvsp[-2].str), criar_no_op_binaria("*", criar_no_variavel((yyvsp[-2].str), yylineno), (yyvsp[0].no), yylineno), yylineno);
            free((yyvsp[-2].str));
        }
#line 2006 "parser/portugol.tab.c"
    break;

  case 77: /* incremento_para: IDENTIFICADOR DIVIDE_IGUAL expressao  */
#line 512 "parser/portugol.y"
        {
            (yyval.no) = criar_no_atribuicao((yyvsp[-2].str), criar_no_op_binaria("/", criar_no_variavel((yyvsp[-2].str), yylineno), (yyvsp[0].no), yylineno), yylineno);
            free((yyvsp[-2].str));
        }
#line 2015 "parser/portugol.tab.c"
    break;

  case 78: /* $@8: %empty  */
#line 520 "parser/portugol.y"
      {
          abrirEscopo(tabela);
      }
#line 2023 "parser/portugol.tab.c"
    break;

  case 79: /* para_comando: PARA ABRE_PAR $@8 inicializacao_para PONTO_VIRGULA expressao PONTO_VIRGULA incremento_para FECHA_PAR ABRE_CHAVE bloco FECHA_CHAVE  */
#line 528 "parser/portugol.y"
        {
            verificar_condicao((yyvsp[-6].no), yylineno, tabela);
            fecharEscopo(tabela);
            (yyval.no) = criar_no_para((yyvsp[-8].no), (yyvsp[-6].no), (yyvsp[-1].no), (yyvsp[-4].no), yylineno);
        }
#line 2033 "parser/portugol.tab.c"
    break;


#line 2037 "parser/portugol.tab.c"

      default: break;
    }
  /* User semantic actions sometimes alter yychar, and that requires
     that yytoken be updated with the new translation.  We take the
     approach of translating immediately before every use of yytoken.
     One alternative is translating here after every semantic action,
     but that translation would be missed if the semantic action invokes
     YYABORT, YYACCEPT, or YYERROR immediately after altering yychar or
     if it invokes YYBACKUP.  In the case of YYABORT or YYACCEPT, an
     incorrect destructor might then be invoked immediately.  In the
     case of YYERROR or YYBACKUP, subsequent parser actions might lead
     to an incorrect destructor call or verbose syntax error message
     before the lookahead is translated.  */
  YY_SYMBOL_PRINT ("-> $$ =", YY_CAST (yysymbol_kind_t, yyr1[yyn]), &yyval, &yyloc);

  YYPOPSTACK (yylen);
  yylen = 0;

  *++yyvsp = yyval;

  /* Now 'shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */
  {
    const int yylhs = yyr1[yyn] - YYNTOKENS;
    const int yyi = yypgoto[yylhs] + *yyssp;
    yystate = (0 <= yyi && yyi <= YYLAST && yycheck[yyi] == *yyssp
               ? yytable[yyi]
               : yydefgoto[yylhs]);
  }

  goto yynewstate;


/*--------------------------------------.
| yyerrlab -- here on detecting error.  |
`--------------------------------------*/
yyerrlab:
  /* Make sure we have latest lookahead translation.  See comments at
     user semantic actions for why this is necessary.  */
  yytoken = yychar == YYEMPTY ? YYSYMBOL_YYEMPTY : YYTRANSLATE (yychar);
  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
      yyerror (YY_("syntax error"));
    }

  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse lookahead token after an
         error, discard it.  */

      if (yychar <= YYEOF)
        {
          /* Return failure if at end of input.  */
          if (yychar == YYEOF)
            YYABORT;
        }
      else
        {
          yydestruct ("Error: discarding",
                      yytoken, &yylval);
          yychar = YYEMPTY;
        }
    }

  /* Else will try to reuse lookahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*---------------------------------------------------.
| yyerrorlab -- error raised explicitly by YYERROR.  |
`---------------------------------------------------*/
yyerrorlab:
  /* Pacify compilers when the user code never invokes YYERROR and the
     label yyerrorlab therefore never appears in user code.  */
  if (0)
    YYERROR;
  ++yynerrs;

  /* Do not reclaim the symbols of the rule whose action triggered
     this YYERROR.  */
  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);
  yystate = *yyssp;
  goto yyerrlab1;


/*-------------------------------------------------------------.
| yyerrlab1 -- common code for both syntax error and YYERROR.  |
`-------------------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;      /* Each real token shifted decrements this.  */

  /* Pop stack until we find a state that shifts the error token.  */
  for (;;)
    {
      yyn = yypact[yystate];
      if (!yypact_value_is_default (yyn))
        {
          yyn += YYSYMBOL_YYerror;
          if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYSYMBOL_YYerror)
            {
              yyn = yytable[yyn];
              if (0 < yyn)
                break;
            }
        }

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
        YYABORT;


      yydestruct ("Error: popping",
                  YY_ACCESSING_SYMBOL (yystate), yyvsp);
      YYPOPSTACK (1);
      yystate = *yyssp;
      YY_STACK_PRINT (yyss, yyssp);
    }

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END


  /* Shift the error token.  */
  YY_SYMBOL_PRINT ("Shifting", YY_ACCESSING_SYMBOL (yyn), yyvsp, yylsp);

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturnlab;


/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturnlab;


/*-----------------------------------------------------------.
| yyexhaustedlab -- YYNOMEM (memory exhaustion) comes here.  |
`-----------------------------------------------------------*/
yyexhaustedlab:
  yyerror (YY_("memory exhausted"));
  yyresult = 2;
  goto yyreturnlab;


/*----------------------------------------------------------.
| yyreturnlab -- parsing is finished, clean up and return.  |
`----------------------------------------------------------*/
yyreturnlab:
  if (yychar != YYEMPTY)
    {
      /* Make sure we have latest lookahead translation.  See comments at
         user semantic actions for why this is necessary.  */
      yytoken = YYTRANSLATE (yychar);
      yydestruct ("Cleanup: discarding lookahead",
                  yytoken, &yylval);
    }
  /* Do not reclaim the symbols of the rule whose action triggered
     this YYABORT or YYACCEPT.  */
  YYPOPSTACK (yylen);
  YY_STACK_PRINT (yyss, yyssp);
  while (yyssp != yyss)
    {
      yydestruct ("Cleanup: popping",
                  YY_ACCESSING_SYMBOL (+*yyssp), yyvsp);
      YYPOPSTACK (1);
    }
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif

  return yyresult;
}

#line 537 "parser/portugol.y"


/* SEÇÃO 4: CÓDIGO C */

int qtd_erros = 0;

void yyerror(const char *s) {
    fprintf(stderr, "Erro na linha %d: %s\n", yylineno, s);
    qtd_erros++;

}

int main(int argc, char *argv[]) {
    tabela = malloc(sizeof(TabelaSimbolos));
    criarTabelaSimbolos(tabela);

    int exibir_ast = 0;
    char *caminho_arquivo = NULL;

    // Percorre os argumentos procurando "--ast" ou o nome do arquivo
    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--ast") == 0) {
            exibir_ast = 1;
        } else {
            caminho_arquivo = argv[i];
        }
    }

    if (caminho_arquivo != NULL) {
        FILE *f = fopen(caminho_arquivo, "r");
        if (!f) {
            perror("Erro ao abrir arquivo");
            limparTabelaSimbolos(tabela);
            free(tabela);
            
            return 1;
        }
        yyin = f;
    } else {
        yyin = stdin;
    }

    printf("=== PARSER PORTUGOL STUDIO UNIVALI ===\n\n");

    int resultado = yyparse();

    if (resultado == 0) {
        printf("\n\n Parse concluído com sucesso!\n");

        if(exibir_ast && qtd_erros == 0){
            printf("\n = = = AST = = =\n");
            ast_imprimir(raiz_ast, 0);
        }

        if(qtd_erros == 0){
            gera_codigo(raiz_ast);
            imprime_tac();
        }
    } else {
        printf("\n\n Erros encontrados durante o parse.\n");
    }

    if (caminho_arquivo != NULL) {
        fclose(yyin);
        printf("\n = = = Tabela de Simbolos = = =\n");

        for(int i = 0; i < tabela->count; i++){
            printf("Nome: %-10s | Tipo: %-8s | Escopo: %d | Linha: %d | Inicializado: %d\n",
            tabela->simbolos[i]->nome,
            tabela->simbolos[i]->tipo,
            tabela->simbolos[i]->escopo,
            tabela->simbolos[i]->linha_declaracao,
            tabela->simbolos[i]->inicializado);
        }
    }

    if(qtd_erros){

        ast_liberar(raiz_ast);

        limparTabelaSimbolos(tabela);
        free(tabela);
        
        return qtd_erros;
    }

    ast_liberar(raiz_ast);
    limparTabelaSimbolos(tabela);
    free(tabela);

    return resultado;
    
}
