/* A Bison parser, made by GNU Bison 3.8.2.  */

/* Bison interface for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015, 2018-2021 Free Software Foundation,
   Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <https://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* DO NOT RELY ON FEATURES THAT ARE NOT DOCUMENTED in the manual,
   especially those whose name start with YY_ or yy_.  They are
   private implementation details that can be changed or removed.  */

#ifndef YY_YY_PARSER_PORTUGOL_TAB_H_INCLUDED
# define YY_YY_PARSER_PORTUGOL_TAB_H_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif
#if YYDEBUG
extern int yydebug;
#endif
/* "%code requires" blocks.  */
#line 51 "parser/portugol.y"

#include "../src/ast.h"

#line 53 "parser/portugol.tab.h"

/* Token kinds.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    YYEMPTY = -2,
    YYEOF = 0,                     /* "end of file"  */
    YYerror = 256,                 /* error  */
    YYUNDEF = 257,                 /* "invalid token"  */
    PROGRAMA = 258,                /* PROGRAMA  */
    FUNCAO = 259,                  /* FUNCAO  */
    INICIO = 260,                  /* INICIO  */
    T_INTEIRO = 261,               /* T_INTEIRO  */
    T_REAL = 262,                  /* T_REAL  */
    T_CADEIA = 263,                /* T_CADEIA  */
    T_LOGICO = 264,                /* T_LOGICO  */
    ESCREVA = 265,                 /* ESCREVA  */
    LEIA = 266,                    /* LEIA  */
    SE = 267,                      /* SE  */
    ENTAO = 268,                   /* ENTAO  */
    SENAO = 269,                   /* SENAO  */
    FIMSE = 270,                   /* FIMSE  */
    ENQUANTO = 271,                /* ENQUANTO  */
    FACA = 272,                    /* FACA  */
    FIMENQUANTO = 273,             /* FIMENQUANTO  */
    PARA = 274,                    /* PARA  */
    ATE = 275,                     /* ATE  */
    FIMPARA = 276,                 /* FIMPARA  */
    RETORNE = 277,                 /* RETORNE  */
    VERDADEIRO = 278,              /* VERDADEIRO  */
    FALSO = 279,                   /* FALSO  */
    E = 280,                       /* E  */
    OU = 281,                      /* OU  */
    NAO = 282,                     /* NAO  */
    ABRE_PAR = 283,                /* ABRE_PAR  */
    FECHA_PAR = 284,               /* FECHA_PAR  */
    ABRE_CHAVE = 285,              /* ABRE_CHAVE  */
    FECHA_CHAVE = 286,             /* FECHA_CHAVE  */
    ABRE_COLCH = 287,              /* ABRE_COLCH  */
    FECHA_COLCH = 288,             /* FECHA_COLCH  */
    VIRGULA = 289,                 /* VIRGULA  */
    PONTO_VIRGULA = 290,           /* PONTO_VIRGULA  */
    DOIS_PONTOS = 291,             /* DOIS_PONTOS  */
    ATRIBUICAO = 292,              /* ATRIBUICAO  */
    IGUAL = 293,                   /* IGUAL  */
    DIFERENTE = 294,               /* DIFERENTE  */
    MENOR = 295,                   /* MENOR  */
    MAIOR = 296,                   /* MAIOR  */
    MENOR_IGUAL = 297,             /* MENOR_IGUAL  */
    MAIOR_IGUAL = 298,             /* MAIOR_IGUAL  */
    MAIS = 299,                    /* MAIS  */
    MENOS = 300,                   /* MENOS  */
    VEZES = 301,                   /* VEZES  */
    DIVIDE = 302,                  /* DIVIDE  */
    MODULO = 303,                  /* MODULO  */
    MAIS_MAIS = 304,               /* MAIS_MAIS  */
    MENOS_MENOS = 305,             /* MENOS_MENOS  */
    MAIS_IGUAL = 306,              /* MAIS_IGUAL  */
    MENOS_IGUAL = 307,             /* MENOS_IGUAL  */
    VEZES_IGUAL = 308,             /* VEZES_IGUAL  */
    DIVIDE_IGUAL = 309,            /* DIVIDE_IGUAL  */
    INCLUA = 310,                  /* INCLUA  */
    CONST = 311,                   /* CONST  */
    CARACTER = 312,                /* CARACTER  */
    PROCEDIMENTO = 313,            /* PROCEDIMENTO  */
    INTEIRO = 314,                 /* INTEIRO  */
    REAL = 315,                    /* REAL  */
    STRING = 316,                  /* STRING  */
    IDENTIFICADOR = 317            /* IDENTIFICADOR  */
  };
  typedef enum yytokentype yytoken_kind_t;
#endif

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
union YYSTYPE
{
#line 57 "parser/portugol.y"

    int inteiro;
    float real;
    char *str;
    AstNode *no;

#line 139 "parser/portugol.tab.h"

};
typedef union YYSTYPE YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif


extern YYSTYPE yylval;


int yyparse (void);


#endif /* !YY_YY_PARSER_PORTUGOL_TAB_H_INCLUDED  */
