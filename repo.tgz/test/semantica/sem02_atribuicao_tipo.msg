Tipo incompativel na atribuicao
