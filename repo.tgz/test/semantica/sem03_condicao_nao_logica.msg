Condicao invalida
