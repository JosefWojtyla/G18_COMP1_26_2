esperava tipos numericos
