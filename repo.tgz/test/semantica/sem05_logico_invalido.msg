espera tipo 'logico'
