Funcao 'soma' nao declarada
